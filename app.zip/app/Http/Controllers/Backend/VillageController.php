<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Division;
use App\Model\District;
use App\Model\Upazilla;
use App\Model\Union;
use App\Model\ward;
use App\Model\Village;

class VillageController extends Controller
{
  public function view()
  {
    $data['allData'] = Village::all();
    return view('backend.village.view-village', $data);
  }

  public function add()
  {
    $data['divisions'] = Division::all();
    return view('backend.village.add-village',$data);
  }

  public function store(Request $request)
  {
    $this->validate($request,[
      'name' => 'required|unique:villages,name',
    ]);

    $data = new Village();
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->union_id = $request->union_id;
    $data->ward_id = $request->ward_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('village.view')->with('success','Data added successfully');
  }

  public function edit($id)
  {
    $data['divisions'] = Division::all();
    $data['editData'] = Village::find($id);
    return view('backend.village.add-village',$data);
  }

  public function update(Request $request, $id)
  {
    $data = Village::find($id);
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->union_id = $request->union_id;
    $data->ward_id = $request->ward_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('village.view')->with('success','Data updated successfully!');

  }

  public function delete($id)
  {
    $user = Village::find($id);
    $user->delete();
    return redirect()->route('village.view')->with('success','Data deleted successfully!');
  }
}
