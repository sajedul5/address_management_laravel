<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Division;
use App\Model\District;
use App\Model\Upazilla;
use App\Model\Union;
use App\Model\ward;
use App\Http\Requests\WardRequest;
class WardController extends Controller
{
  public function view()
  {
    $data['allData'] = Ward::all();
    return view('backend.ward.view-ward', $data);
  }

  public function add()
  {
    $data['divisions'] = Division::all();
    return view('backend.ward.add-ward',$data);
  }

  public function store(Request $request)
  {
    $this->validate($request,[
      'ward_no' => 'required|unique:wards,ward_no',
    ]);

    $data = new Ward();
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->union_id = $request->union_id;
    $data->ward_no = $request->ward_no;
    $data->save();
    return redirect()->route('ward.view')->with('success','Data added successfully');
  }

  public function edit($id)
  {
    $data['divisions'] = Division::all();
    $data['editData'] = Ward::find($id);
    return view('backend.ward.add-ward',$data);
  }

  public function update(WardRequest $request, $id)
  {
    $data = Ward::find($id);
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->union_id = $request->union_id;
    $data->ward_no = $request->ward_no;
    $data->save();
    return redirect()->route('ward.view')->with('success','Data updated successfully!');

  }

  public function delete($id)
  {
    $user = Ward::find($id);
    $user->delete();
    return redirect()->route('ward.view')->with('success','Data deleted successfully!');
  }
}
