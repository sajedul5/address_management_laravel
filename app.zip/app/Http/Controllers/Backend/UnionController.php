<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Division;
use App\Model\District;
use App\Model\Upazilla;
use App\Model\Union;
use App\Http\Requests\UnionRequest;
class UnionController extends Controller
{
  public function view()
  {
    $data['allData'] = Union::all();
    return view('backend.union.view-union', $data);
  }

  public function add()
  {
    $data['divisions'] = Division::all();
    return view('backend.union.add-union',$data);
  }

  public function store(Request $request)
  {
    $this->validate($request,[
      'name' => 'required|unique:unions,name',
    ]);

    $data = new Union();
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('union.view')->with('success','Data added successfully');
  }

  public function edit($id)
  {
    $data['divisions'] = Division::all();
    $data['editData'] = Union::find($id);
    return view('backend.union.add-union',$data);
  }

  public function update(UnionRequest $request, $id)
  {
    $data = Union::find($id);
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->upazilla_id = $request->upazilla_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('union.view')->with('success','Data updated successfully!');

  }

  public function delete($id)
  {
    $user = Union::find($id);
    $user->delete();
    return redirect()->route('union.view')->with('success','Data deleted successfully!');
  }
}
