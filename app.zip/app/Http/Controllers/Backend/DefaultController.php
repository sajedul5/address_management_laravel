<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\District;
use App\Model\Upazilla;
use App\Model\Union;
use App\Model\Ward;
class DefaultController extends Controller
{
    public function getDistrict(Request $request)
    {
      $division_id = $request->division_id;
      $allDistrict = District::where('division_id', $division_id)->get();
      return response()->json($allDistrict);
    }

    public function getUpazilla(Request $request)
    {
      $district_id = $request->district_id;
      $allUpazilla = Upazilla::where('district_id', $district_id)->get();
      return response()->json($allUpazilla);
    }

    public function getUnion(Request $request)
    {
      $upazilla_id = $request->upazilla_id;
      $allUnion = Union::where('upazilla_id', $upazilla_id)->get();
      return response()->json($allUnion);
    }

    public function getWard(Request $request)
    {
      $union_id = $request->union_id;
      $allWard = Ward::where('union_id', $union_id)->get();
      return response()->json($allWard);
    }


}
