<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Division;
use App\Model\District;
use App\Http\Requests\DistrictRequest;
class DistrictController extends Controller
{
  public function view()
  {
    $data['allData'] = District::all();
    return view('backend.district.view-district', $data);
  }

  public function add()
  { $data['divisions'] = Division::all();
    return view('backend.district.add-district',$data);
  }

  public function store(Request $request)
  {
    $this->validate($request,[
      'name' => 'required|unique:districts,name',
    ]);

    $data = new District();
    $data->division_id = $request->division_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('district.view')->with('success','Data added successfully');
  }

  public function edit($id)
  {
    $data['divisions'] = Division::all();
    $data['editData'] = District::find($id);
    return view('backend.district.add-district',$data);
  }

  public function update(DistrictRequest $request, $id)
  {
    $data = District::find($id);
    $data->name = $request->name;
    $data->save();
    return redirect()->route('district.view')->with('success','Data updated successfully!');

  }

  public function delete($id)
  {
    $user = District::find($id);
    $user->delete();
    return redirect()->route('district.view')->with('success','Data deleted successfully!');
  }
}
