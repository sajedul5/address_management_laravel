<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Division;
use App\Model\District;
use App\Model\Upazilla;
use App\Http\Requests\UpazillaRequest;
class UpazillaController extends Controller
{
  public function view()
  {
    $data['allData'] = Upazilla::all();
    return view('backend.upazilla.view-upazilla', $data);
  }

  public function add()
  {
    $data['divisions'] = Division::all();
    return view('backend.upazilla.add-upazilla',$data);
  }

  public function store(Request $request)
  {
    $this->validate($request,[
      'name' => 'required|unique:upazillas,name',
    ]);

    $data = new Upazilla();
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('upazilla.view')->with('success','Data added successfully');
  }

  public function edit($id)
  {
    $data['divisions'] = Division::all();
    $data['editData'] = Upazilla::find($id);
    return view('backend.upazilla.add-upazilla',$data);
  }

  public function update(UpazillaRequest $request, $id)
  {
    $data = Upazilla::find($id);
    $data->division_id = $request->division_id;
    $data->district_id = $request->district_id;
    $data->name = $request->name;
    $data->save();
    return redirect()->route('upazilla.view')->with('success','Data updated successfully!');

  }

  public function delete($id)
  {
    $user = Upazilla::find($id);
    $user->delete();
    return redirect()->route('upazilla.view')->with('success','Data deleted successfully!');
  }
}
